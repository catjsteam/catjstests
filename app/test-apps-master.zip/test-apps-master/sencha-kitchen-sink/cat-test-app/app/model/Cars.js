Ext.define('Kitchensink.model.Cars', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            {name: 'text', type: 'string'}
        ]
    }
});
