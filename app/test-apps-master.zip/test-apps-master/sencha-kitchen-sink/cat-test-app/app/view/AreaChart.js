/**
 * Demonstrates how use Ext.chart.LineChart
 */
