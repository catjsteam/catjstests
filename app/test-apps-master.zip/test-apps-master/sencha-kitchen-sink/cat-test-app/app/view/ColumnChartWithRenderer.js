/**
 * Demonstrates how use Ext.chart.ColumnChart with a renderer function
 */
