/**
 * Demonstrates how use Ext.chart.ColumnChart
 */
