/**
 * Demonstrates how use Ext.chart.ColumnChartStacked
 */
