/**
 * Demonstrates how use Ext.chart.series.Line with a renderer function
 */
