/**
 * Demonstrates a Map component
 */
Ext.define('Kitchensink.view.Map', {
    extend: 'Ext.Map'
});
