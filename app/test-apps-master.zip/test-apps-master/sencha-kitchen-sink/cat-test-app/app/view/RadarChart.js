/**
 * Demonstrates how use Ext.chart.series.Radar
 */
