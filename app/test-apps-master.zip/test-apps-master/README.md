CatJS Test Apps
======================

This is the test applications that are being used to test CatJS framework and tool.  
This folder is hooked to the "npm install" command of the CatJS Node Module.  
The applications that participates as part of the CI test are: catjs_example, enyo and sencha
