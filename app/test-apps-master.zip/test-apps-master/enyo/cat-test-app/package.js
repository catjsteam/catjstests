
enyo.load([
  "app.js" + "?" + (new Date()).getTime()
]);

